# Visual quality assurance

## Typography

- Keep a horizontal margin of at least 7%.
- Preserve natural upper/lowercase and Vietnamese diacritics.
- Make the title visibly larger than supporting text.
- Keep line spacing compact but breathable and avoid unexplained gaps.
- Use a matte highlight without glow or outline unless requested.
- Keep the fixed text block inside the central safe region.

## Logo placement

- Preserve aspect ratio and transparency.
- Start around 7-10% of frame width.
- Align with the visual axis of the content block.
- Prefer a stable empty region across the clip.
- Never overlap a face, eyes, hands, product, title, or body text.
- Inspect at 25%, 50%, and 75% of duration. Move or omit the logo if no safe region persists.

## Preview checklist

- Correct 9:16 dimensions and duration
- Text matches approved source
- No clipped or overflowing line
- Readable at phone size
- Background recognizable but subdued
- Logo relevant, proportional, and unobtrusive
- Audio present, balanced, and faded cleanly
- No black frame, frozen ending, accidental source audio, or consecutive footage duplicate

Correct failed checks and rerender before presenting the result.
